package at.htl;

public interface CounterInterface {

    void increment();

    int getValue();

}
