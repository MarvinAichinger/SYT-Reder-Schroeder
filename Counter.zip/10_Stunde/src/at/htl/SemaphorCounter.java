package at.htl;

import java.util.concurrent.Semaphore;

public class SemaphorCounter extends Counter {

    private Semaphore semaphore = new Semaphore(1, true); //fair viel langsamer

    @Override
    public void increment() {
        semaphore.acquireUninterruptibly();
        super.increment();
        semaphore.release();
    }

}
